
//line x2.go:4
package main
func F2() {}
