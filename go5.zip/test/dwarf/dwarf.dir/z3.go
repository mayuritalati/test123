
//line x3.go:4
package main
func F3() {}
